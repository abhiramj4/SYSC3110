package testing;

import controller.Game;
import junit.framework.TestCase;
import board.Coordinate;
import org.junit.Test;
import static org.junit.Assert.*;

public class CoordinateTest extends TestCase{

	public static void main(String[] args) {
		junit.textui.TestRunner.run(CoordinateTest.class);
	}
}
