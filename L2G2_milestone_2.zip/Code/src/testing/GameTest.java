package testing;

import controller.Game;
import junit.framework.TestCase;
import board.Coordinate;
import org.junit.Test;
import static org.junit.Assert.*;

public class GameTest extends TestCase{
	
	private Game g;
	
	public GameTest() {	}
	
	protected void setUp() {
		g = new Game();
	}
	
	@Test
	public void testBuild() {
		
	}
	
	public static void main(String[] args) {
		junit.textui.TestRunner.run(GameTest.class);
	}

}
