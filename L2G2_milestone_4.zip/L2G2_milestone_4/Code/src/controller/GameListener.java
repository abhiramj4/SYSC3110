package controller;

/**
 * @author Abhi Santhosh
 *
 */
public interface GameListener {

	public void update(Game g, String type);

}
